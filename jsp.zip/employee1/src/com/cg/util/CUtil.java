package com.cg.util;

import java.util.HashMap;

import com.cg.bean.Product;

public class CUtil 
{
private static HashMap<Integer,Product> hm=new HashMap<Integer,Product>();

public static void sethm(int pid,Product p)
{
	hm.put(pid,p);
}
public static HashMap<Integer,Product> gethm()
{
	return hm;
	
}

}
