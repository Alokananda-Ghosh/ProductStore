package com.cg.service;

import java.util.HashMap;

import com.cg.Dao.IDao;
import com.cg.Dao.IDaoImpl;
import com.cg.bean.Product;

public class IServiceImpl implements IService{
IDao dp=new IDaoImpl();

@Override
public int setProduct(int pid,Product p) {
	// TODO Auto-generated method stub
	return dp.setProduct(pid,p);
}

@Override
public Product getProduct(int pid) {
	// TODO Auto-generated method stub
return dp.getProduct(pid);
}

@Override
public HashMap<Integer, Product> getAll() {
	// TODO Auto-generated method stub
	return dp.getAll();
}

	
}
